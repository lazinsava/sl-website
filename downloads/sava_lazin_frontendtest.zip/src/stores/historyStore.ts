import { defineStore } from "pinia";

export const useHistoryStore = defineStore("historyStore", {
  state: () => ({
    history: <string[]>[],
  }),
  getters: {
    getHistory: (state) => {
      return state.history;
    },
  },
  actions: {
    addHistory(move: string) {
      this.history.push(move);
    },
  },
});
