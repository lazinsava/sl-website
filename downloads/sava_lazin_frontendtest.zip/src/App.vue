<template>
  <div class="container">
    <Chessboard />
    <Sidebar />
  </div>
</template>

<script setup lang="ts">
import Chessboard from "./components/Chessboard.vue";
import Sidebar from "./components/Sidebar.vue";
</script>

<style scoped>
.container {
  width: 100%;
  max-width: 1200px;
  margin: 100px auto;
  padding: 20px;

  @media screen and (min-width: 1025px) {
    display: flex;
    flex-direction: row;
    justify-content: center;
  }
}
</style>
