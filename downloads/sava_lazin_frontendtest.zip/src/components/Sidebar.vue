<template>
  <div class="sidebar">
    <h2 class="sidebar__title">History</h2>
    <div v-for="(move, index) in history" :key="move">
      {{ index + 1 }}. {{ move }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { useHistoryStore } from "../stores/historyStore";

const historyStore = useHistoryStore();

const history = computed(() => historyStore.getHistory);
</script>

<style scoped>
.sidebar {
  width: 200px;
  padding: 20px;
}

.sidebar__title {
  margin-bottom: 20px;
}
</style>
