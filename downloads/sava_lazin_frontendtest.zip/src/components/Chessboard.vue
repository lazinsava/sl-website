<template>
  <div class="chessboard">
    <div
      v-for="square in board"
      :key="square.position"
      class="chessboard__square"
      :class="[
        currentMove === square.position
          ? 'chessboard__square--current-move'
          : `chessboard__square--${square.color}`,
      ]"
      @click="handleClick(square.position)"
    >
      {{ square.position }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { useHistoryStore } from "../stores/historyStore";

const historyStore = useHistoryStore();

const chars = ["a", "b", "c", "d", "e", "f", "g", "h"];
const nums = [1, 2, 3, 4, 5, 6, 7, 8];
const currentMove = ref("");
const board: { position: string; color: string }[] = [];

function generateBoard() {
  nums.reverse().forEach((num) => {
    chars.forEach((char) => {
      board.push({
        position: `${char}${num}`,
        color:
          (chars.indexOf(char) + nums.indexOf(num)) % 2 === 0
            ? "white"
            : "black",
      });
    });
  });
}

function handleClick(square: string) {
  if (currentMove.value === square) return;

  currentMove.value = square;
  historyStore.addHistory(square);
}

generateBoard();
</script>

<style scoped>
.chessboard {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  grid-template-rows: repeat(8, 1fr);
  width: 100%;
  border: 1px solid #000000;
}

.chessboard__square {
  aspect-ratio: 1 / 1;
}

.chessboard__square--black {
  color: #ffffff;
  background-color: #000000;
}

.chessboard__square--white {
  color: #000000;
  background-color: #ffffff;
}

.chessboard__square--current-move {
  background-color: rgba(10, 77, 65, 0.25);
}
</style>
